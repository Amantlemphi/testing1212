// ═══════════════════════════════════════════════
//  CAMP PORTAL — FIREBASE CONFIG & SHARED DATA
//  Uses the same afc-botswana Firebase project
// ═══════════════════════════════════════════════
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, doc, updateDoc, deleteDoc, query, orderBy, onSnapshot, where, serverTimestamp }
  from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCsRVjm8GYT78x0BPFVMoTtpRj2H96EfBI",
  authDomain: "afc-botswana.firebaseapp.com",
  projectId: "afc-botswana",
  storageBucket: "afc-botswana.firebasestorage.app",
  messagingSenderId: "112173481312",
  appId: "1:112173481312:web:a0f416e326442f788f3205"
};

const app  = initializeApp(firebaseConfig);
const db   = getFirestore(app);
const auth = getAuth(app);

// ── COLLECTIONS ──
const CAMP_REGS      = "camp_registrations";
const CAMP_ORDERS    = "camp_orders";
const CAMP_ANN       = "camp_announcements";
const CAMP_ATT       = "camp_attendance";
const CAMP_PRAYERS   = "camp_prayers";
const CAMP_JOURNAL   = "camp_journal";
const CAMP_TESTIM    = "camp_testimonies";
const STORE_PRODUCTS = "store_products";

// ── ROLE PASSWORDS stored as Firestore config ──
// For simplicity, passwords are checked client-side
// (Firebase Auth handles the camp manager login; store/usher use passcodes)
const ROLE_PASSCODES = {
    admin: "admin0987",
  store: "store2025",
  usher: "usher2025"
};

export {
  db, auth,
  collection, addDoc, getDocs, doc, updateDoc, deleteDoc,
  query, orderBy, onSnapshot, where, serverTimestamp,
  signInWithEmailAndPassword, signOut, onAuthStateChanged,
  CAMP_REGS, CAMP_ORDERS, CAMP_ANN, CAMP_ATT,
  CAMP_PRAYERS, CAMP_JOURNAL, CAMP_TESTIM,
  ROLE_PASSCODES, STORE_PRODUCTS
};